<!-- Game from https://www.gamearter.com/ -->
<div class="card">
  <div class="card-header bg-info text-white text-center">Play Tiger Jigsaw</div>
  <div class="card-body text-center">
    <iframe src="https://www.gamearter.com/game/tiger-jigsaw/"
            allow="fullscreen"
            class = "kidsGame">
          </iframe>
  </div>
</div>


<!-- Game from https://www.gamearter.com/ -->
<div class="card">
  <div class="card-header bg-info text-white text-center">Play Jungle Matching</div>
  <div class="card-body text-center">
    <iframe src="https://www.gamearter.com/game/jungle-matching/"
            allow="fullscreen"
            class = "kidsGame">
          </iframe>
  </div>
</div>

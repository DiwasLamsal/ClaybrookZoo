<?php
  header("Location: /ZooAssignment/public/");
 ?>

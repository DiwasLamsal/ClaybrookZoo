<?php
  echo $contents;
?>

<?php


  require_once '../app/pdoconnect/pdoconnect.php';
  require_once '../app/models/databasetable.php';
  require_once '../app/functions/functions.php';
  require_once '../app/functions/otherDatabaseFunctions.php';
  require_once '../app/init.php';

  $app = new App;

?>
